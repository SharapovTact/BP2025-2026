UNIT WordParse;

INTERFACE
CONST
  CorrectValues = ['-', 'A' .. 'Z', 'a' .. 'z', '�' .. '�', '�' .. '�'];
  LowCase = 'abcdefghijklmnopqrstuvwxyz��������������������������������';
  HighCase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ�����Ũ��������������������������';

FUNCTION LowerCase(Word: STRING): STRING;
FUNCTION ReadWord(VAR FIn: TEXT): STRING;

IMPLEMENTATION

FUNCTION LowerCase(Word: STRING): STRING;
VAR
  Len, I, J: INTEGER;
  Ch: CHAR;
  LowerCaseWord: STRING;
BEGIN {LowerCase}
  Len := Length(Word);
  LowerCaseWord := '';
  FOR I := 1 TO Len
  DO
    BEGIN
      Ch := Word[I];
      FOR J := 1 TO Length(LowCase)
      DO               
        IF HighCase[J] = Ch
        THEN
          Ch := LowCase[J];
      LowerCaseWord := LowerCaseWord + Ch
    END;
  LowerCase := LowerCaseWord
END; {LowerCase}

FUNCTION CorrectionWord(Word: STRING): STRING;
VAR
  CorrectWord: STRING;
  Ch: CHAR;
  I, Len: INTEGER;
  DashFound: BOOLEAN;
BEGIN {CorrectionWord}
  DashFound := FALSE;
  CorrectWord := '';
  I := 0;
  Ch := '-';
  Len := Length(Word);
  WHILE (Ch = '-') AND (I <> Len + 1)
  DO
    BEGIN
      I := I + 1;
      Ch := Word[I]
    END;
  WHILE I <> Len + 1
  DO
    BEGIN
      Ch := Word[I];
      IF DashFound AND (Ch <> '-')
      THEN
        BEGIN
          CorrectWord := CorrectWord + '-';
          DashFound := FALSE
        END;
      IF (Ch <> '-')
      THEN
        CorrectWord := CorrectWord + Ch
      ELSE
        IF DashFound <> TRUE
        THEN 
          DashFound := TRUE;
      I := I + 1
    END;
  CorrectionWord := CorrectWord
END; {CorrectionWord} 

FUNCTION ReadWord(VAR FIn: TEXT): STRING;
VAR
  Ch: CHAR; 
  Word: STRING;
BEGIN {ReadWord}
  Word := '';
  IF NOT EOLN(FIn)
  THEN
    READ(FIn, Ch);
  WHILE (NOT EOLN(FIn)) AND (Ch IN CorrectValues)
  DO
    BEGIN
      Word := Word + Ch;
      READ(FIn, Ch)
    END;
  IF Ch IN CorrectValues
  THEN
    Word := Word + Ch;
  Word := CorrectionWord(Word);
  IF EOLN(FIn)
  THEN
    READLN(FIn);
  ReadWord := LowerCase(Word)
END; {ReadWord}

END.
